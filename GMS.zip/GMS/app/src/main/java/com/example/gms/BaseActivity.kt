package com.example.gms

import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

open class BaseActivity : AppCompatActivity() {
    val permissions = arrayOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION")
    lateinit var locationManager: LocationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationManager =
            this.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    fun onInit() {
        if(!checkPermissions(permissions)) {
            requestPermissions(permissions)
        }
        else {
            onSuccess()
        }
    }

    fun checkPermissions(permissions: Array<String>): Boolean {
        permissions.forEach {
            val what = ContextCompat.checkSelfPermission(this, it)
            if(what != PackageManager.PERMISSION_GRANTED) {
                return false
            }
        }
        return true
    }

    fun requestPermissions(permissions: Array<String>) {
        ActivityCompat.requestPermissions(this, permissions, 1001)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(checkPermissions(this.permissions)) {
            onSuccess()
        }
    }

    open fun onSuccess() {}
}