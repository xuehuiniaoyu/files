package com.example.gms

import android.os.Bundle
import kotlin.concurrent.thread
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.location.*
import android.widget.Toast
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.HashMap
import android.location.LocationManager


open abstract class BaseLocationListener : LocationListener {
    override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {
        //To change body of created functions use File | Settings | File Templates.
    }

    override fun onProviderEnabled(p0: String?) {
        //To change body of created functions use File | Settings | File Templates.
    }

    override fun onProviderDisabled(p0: String?) {
        //To change body of created functions use File | Settings | File Templates.
    }
}

class MainActivity : BaseActivity() {

    inner class MyLocationListener : BaseLocationListener(){
        override fun onLocationChanged(location: Location?) {
            if(location != null) {
                locationManager.removeUpdates(this)
                convertToAddress(location)
                loadingDialog?.dismiss()
                loadingDialog = null
            }
        }
    }

    var locationListener_GPS: MyLocationListener? = MyLocationListener()
    var locationListener_WIFI: MyLocationListener? = MyLocationListener()
    var locationListener_DEFAULT: MyLocationListener? = MyLocationListener()

    var countrys = HashMap<String, String>()
    var loadingDialog: ProgressDialog? = null
    var googleServiceOk = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val googleApiAvailability = GoogleApiAvailability.getInstance();
        val resultCode = googleApiAvailability.isGooglePlayServicesAvailable(this);
        if(resultCode != ConnectionResult.SUCCESS) {
            if(googleApiAvailability.isUserResolvableError(resultCode)) {
                googleApiAvailability.getErrorDialog(this, resultCode, 2404).show();
            }
            Toast.makeText(this, "Your phone does not support Google services", Toast.LENGTH_LONG).show()
        }
        else {
            googleServiceOk = true
        }


        Locale.getISOCountries().forEach {
            val locale = Locale("", it)
            countrys[locale.displayCountry] = it
        }
        onInit()
    }

    @SuppressLint("MissingPermission")
    fun requestLocation(mLocationManager: LocationManager) {
        loadingDialog = ProgressDialog.show(this, "GPS定位", "定位中,请稍后..."
            ,false,false);
        mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0F, locationListener_GPS)
        mLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0F, locationListener_WIFI)
        mLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0F, locationListener_DEFAULT)
    }

    @SuppressLint("MissingPermission")
    fun getLastKnownLocation(mLocationManager: LocationManager): Location? {
        val criteria = Criteria()
        criteria.accuracy = Criteria.ACCURACY_FINE//高精度
        criteria.isAltitudeRequired = false//无海拔要求   criteria.setBearingRequired(false);//无方位要求
        criteria.isCostAllowed = true//允许产生资费   criteria.setPowerRequirement(Criteria.POWER_LOW);//低功耗

        // 获取最佳服务对象
        val provider = mLocationManager.getBestProvider(criteria, true)
        return mLocationManager.getLastKnownLocation(provider)
    }

    fun convertToAddress(location: Location) {
        thread {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            if(addresses.isNullOrEmpty().not()) {
                val address = addresses[0]
                runOnUiThread {
                    mText.text = address.toString()
                    countryCode.text = address.countryCode
                    countryName.text = address.countryName
                    locale.text = countrys[address.countryName]
                }
            }
        }
    }

    override fun onSuccess() {
        button.setOnClickListener {
            if(googleServiceOk) {
                val lastLocation = getLastKnownLocation(locationManager)
                if (lastLocation != null) {
                    convertToAddress(lastLocation)
                } else {
                    requestLocation(locationManager)
                }
            }
            else {
                Toast.makeText(this, "Your phone does not support Google services", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        locationManager.removeUpdates(locationListener_DEFAULT)
        locationManager.removeUpdates(locationListener_WIFI)
        locationManager.removeUpdates(locationListener_GPS)
    }
}
